const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const db = mysql.createConnection({
    host: 'localhost',
    port: '3307',
    user: 'root',
    password: '',
    database: 'db_toko_besar'
});

db.connect((err) => {
    if (err) {
        console.error('Koneksi Database Gagal: ', err);
    } else {
        console.log('Berhasil Terhubung ke Database db_toko_besar!');
    }
});

// ==========================================
// ENDPOINT CONTOH / SAPAAN
// ==========================================
app.get('/api/sapaan', (req, res) => {
    res.status(200).json({
        status: 'success',
        message: 'Halo! Selamat datang di Server Express.'
    });
});

// ==========================================
// ENDPOINT CRUD TABEL PELANGGAN
// ==========================================
app.get('/api/pelanggan', (req, res) => {
    const sql = "SELECT * FROM tbl_pelanggan ORDER BY id_pelanggan DESC";
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Berhasil mengambil data", data: results });
    });
});

app.post('/api/pelanggan', (req, res) => {
    const { nama_pelanggan, kota } = req.body;

    if (!nama_pelanggan || !kota) {
        return res.status(400).json({
            status: 'error',
            message: 'Gagal! Nama pelanggan dan kota wajib diisi.'
        });
    }

    const sql = "INSERT INTO tbl_pelanggan (nama_pelanggan, kota) VALUES (?, ?)";
    db.query(sql, [nama_pelanggan, kota], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Data pelanggan berhasil ditambahkan!", id: results.insertId });
    });
});

app.put('/api/pelanggan/:id', (req, res) => {
    const id_pelanggan = req.params.id;
    const { nama_pelanggan, kota } = req.body;
    const sql = "UPDATE tbl_pelanggan SET nama_pelanggan = ?, kota = ? WHERE id_pelanggan = ?";
    db.query(sql, [nama_pelanggan, kota, id_pelanggan], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Data pelanggan berhasil diupdate!" });
    });
});

app.delete('/api/pelanggan/:id', (req, res) => {
    const id_pelanggan = req.params.id;
    const sql = "DELETE FROM tbl_pelanggan WHERE id_pelanggan = ?";
    db.query(sql, [id_pelanggan], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ message: "Data pelanggan berhasil dihapus!" });
    });
});

// ==========================================
// ENDPOINT CRUD TABEL TRANSAKSI
// ==========================================
app.get('/api/transaksi', (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const offset = (page - 1) * limit;

    const countSql = "SELECT COUNT(*) AS total FROM tbl_transaksi";
    const sql = `
        SELECT
            t.id_transaksi,
            DATE_FORMAT(t.tanggal, '%Y-%m-%d') AS tanggal,
            t.id_pelanggan,
            COALESCE(p.nama_pelanggan, 'Pelanggan Tidak Ditemukan') AS nama_pelanggan,
            COALESCE(p.kota, '-') AS kota,
            t.total_belanja
        FROM tbl_transaksi t
        LEFT JOIN tbl_pelanggan p ON t.id_pelanggan = p.id_pelanggan
        ORDER BY t.id_transaksi DESC
        LIMIT ? OFFSET ?
    `;

    db.query(countSql, (err, countResult) => {
        if (err) return res.status(500).json({ success: false, error: err.message });
        const totalRecords = countResult[0].total;
        const totalPages = Math.ceil(totalRecords / limit);

        db.query(sql, [limit, offset], (err, results) => {
            if (err) return res.status(500).json({ success: false, error: err.message });
            res.json({
                success: true,
                message: "Berhasil mengambil data transaksi",
                page,
                limit,
                totalRecords,
                totalPages,
                data: results
            });
        });
    });
});

app.get('/api/transaksi/stats', (req, res) => {
    const sql = `
        SELECT
            COUNT(*) AS total_transaksi,
            COALESCE(SUM(total_belanja), 0) AS total_omset,
            COALESCE(AVG(total_belanja), 0) AS rata_rata
        FROM tbl_transaksi
    `;
    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ success: false, error: err.message });
        res.json({ success: true, data: results[0] });
    });
});

app.post('/api/transaksi', (req, res) => {
    const { tanggal, id_pelanggan, total_belanja } = req.body;

    if (!tanggal || !id_pelanggan || total_belanja === undefined || total_belanja === null) {
        return res.status(400).json({
            success: false,
            message: "Tanggal, ID Pelanggan, dan Total Belanja wajib diisi!"
        });
    }

    const sql = "INSERT INTO tbl_transaksi (tanggal, id_pelanggan, total_belanja) VALUES (?, ?, ?)";
    db.query(sql, [tanggal, id_pelanggan, total_belanja], (err, results) => {
        if (err) return res.status(500).json({ success: false, error: err.message });
        res.status(201).json({
            success: true,
            message: "Transaksi baru berhasil disimpan!",
            id_transaksi: results.insertId
        });
    });
});

app.put('/api/transaksi/:id', (req, res) => {
    const id_transaksi = req.params.id;
    const { tanggal, id_pelanggan, total_belanja } = req.body;

    if (!tanggal || !id_pelanggan || total_belanja === undefined || total_belanja === null) {
        return res.status(400).json({
            success: false,
            message: "Tanggal, ID Pelanggan, dan Total Belanja wajib diisi!"
        });
    }

    const sql = "UPDATE tbl_transaksi SET tanggal = ?, id_pelanggan = ?, total_belanja = ? WHERE id_transaksi = ?";
    db.query(sql, [tanggal, id_pelanggan, total_belanja, id_transaksi], (err, results) => {
        if (err) return res.status(500).json({ success: false, error: err.message });

        if (results.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: `Transaksi dengan ID #${id_transaksi} tidak ditemukan!`
            });
        }

        res.json({
            success: true,
            message: "Data transaksi berhasil diperbarui!"
        });
    });
});

app.delete('/api/transaksi/:id', (req, res) => {
    const id_transaksi = req.params.id;
    const sql = "DELETE FROM tbl_transaksi WHERE id_transaksi = ?";

    db.query(sql, [id_transaksi], (err, results) => {
        if (err) return res.status(500).json({ success: false, error: err.message });

        if (results.affectedRows === 0) {
            return res.status(404).json({
                success: false,
                message: `Transaksi dengan ID #${id_transaksi} tidak ditemukan!`
            });
        }

        res.json({
            success: true,
            message: "Data transaksi berhasil dihapus!"
        });
    });
});

// ==========================================
// ENDPOINT LAPORAN KEUANGAN BULANAN
// ==========================================
app.get('/api/laporan/bulanan', (req, res) => {
    const sql = `
        SELECT
            DATE_FORMAT(tanggal, '%Y-%m') AS periode,
            DATE_FORMAT(tanggal, '%M %Y') AS label,
            COUNT(*) AS total_transaksi,
            COALESCE(SUM(total_belanja), 0) AS total_omset
        FROM tbl_transaksi
        GROUP BY periode
        ORDER BY periode DESC
    `;

    db.query(sql, (err, results) => {
        if (err) return res.status(500).json({ success: false, error: err.message });

        const data = results.map((row, index) => {
            const bulanSebelumnya = results[index + 1];
            let perubahan_persen = null;
            let naik = null;

            if (bulanSebelumnya && bulanSebelumnya.total_omset > 0) {
                perubahan_persen = ((row.total_omset - bulanSebelumnya.total_omset) / bulanSebelumnya.total_omset) * 100;
                naik = perubahan_persen >= 0;
            }

            return {
                periode: row.periode,
                label: row.label,
                total_transaksi: row.total_transaksi,
                total_omset: row.total_omset,
                perubahan_persen: perubahan_persen !== null ? Number(perubahan_persen.toFixed(2)) : null,
                naik
            };
        });

        res.json({ success: true, data });
    });
});

// Jalankan Server
app.listen(PORT, () => {
    console.log(`🚀 Server berjalan di http://localhost:${PORT}`);
});